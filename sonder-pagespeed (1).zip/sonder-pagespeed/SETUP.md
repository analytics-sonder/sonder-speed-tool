# SONDER DIGITAL — Speed Analyser: Deployment & Data Setup Guide

## What's in this package

```
sonder-pagespeed/
├── public/
│   └── index.html                  ← The full tool (SEO-optimised, branded)
├── netlify/
│   └── functions/
│       ├── log-analysis.js         ← Logs every URL analysed
│       └── submit-lead.js          ← Captures consultation form leads
├── netlify.toml                    ← Netlify build + header config
├── Sonder_Digital_Speed_Tracker.xlsx ← Excel tracker (Analyses + Leads + Dashboard)
└── SETUP.md                        ← This file
```

---

## STEP 1 — Deploy to Netlify

### Option A: Drag & Drop (fastest)
1. Go to [app.netlify.com](https://app.netlify.com) → **Add new site → Deploy manually**
2. Drag the entire `sonder-pagespeed/` folder into the Netlify drop zone
3. Netlify detects `netlify.toml` automatically — functions deploy alongside the site
4. Your site is live at a `*.netlify.app` URL in ~30 seconds

### Option B: Git deploy (recommended for ongoing updates)
1. Push `sonder-pagespeed/` to a GitHub/GitLab repo
2. Netlify → **Add new site → Import from Git** → connect your repo
3. Build settings (auto-detected from `netlify.toml`):
   - **Publish directory:** `public`
   - **Functions directory:** `netlify/functions`

### Connecting your custom domain
1. Netlify dashboard → **Domain management → Add custom domain**
2. Enter e.g. `pagespeed.sonderdigital.com`
3. Add a CNAME record at your DNS provider:
   - **Host:** `pagespeed`
   - **Value:** `<your-netlify-site>.netlify.app`
4. Netlify auto-provisions a free SSL certificate via Let's Encrypt

---

## STEP 2 — Google Sheets is already connected ✅

Your Apps Script webhook is hardwired into both Netlify functions — **no environment variables needed.**

Webhook URL in use:
```
https://script.google.com/macros/s/AKfycbzgJh5CdMcz71Qolje08ouyr3T-X8_k5giKdTXFDR8hzlS2u9VLaKQbufWiZFCB0dJA/exec
```

### Make sure your Google Sheet has these two tabs with the correct headers:

**Tab name: `Analyses`** — Row 1 headers (columns A–I):
```
Timestamp | URL | Device | Performance | Accessibility | Best Practices | SEO | Referrer | User Agent
```

**Tab name: `Leads`** — Row 1 headers (columns A–G):
```
Timestamp | Name | Company | Title | Email | Phone | Analysed URL
```

### Verify your Apps Script is deployed correctly
1. Open the Google Sheet → **Extensions → Apps Script**
2. Confirm the `doPost(e)` function exists (see code below)
3. **Deploy → Manage deployments** → confirm it's deployed as a **Web app** with access set to **Anyone**

Required Apps Script code (if not already in place):
```javascript
function doPost(e) {
  try {
    const data = JSON.parse(e.postData.contents);
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const sheet = ss.getSheetByName(data.sheet);
    if (!sheet) return ContentService.createTextOutput("Sheet not found");
    sheet.appendRow(data.row);
    return ContentService.createTextOutput(JSON.stringify({ success: true }))
      .setMimeType(ContentService.MimeType.JSON);
  } catch (err) {
    return ContentService.createTextOutput(JSON.stringify({ error: err.message }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}
```

Once deployed, every URL analysis and lead form submission will automatically append a row to the correct tab in your Google Sheet.

---

## STEP 3 — Using the Excel tracker

The included `Sonder_Digital_Speed_Tracker.xlsx` has three sheets:

| Sheet | Purpose |
|-------|---------|
| **Analyses** | Paste exported rows from Google Sheets / Airtable weekly |
| **Leads** | Paste lead data for CRM import or direct follow-up |
| **Dashboard** | Auto-calculating KPIs — total analyses, avg scores, lead count |

**To refresh the dashboard:** paste new rows into Analyses and Leads — all Dashboard formulas update automatically.

**To export from Google Sheets to Excel:**
File → Download → Microsoft Excel (.xlsx) → copy rows into the tracker

---

## STEP 4 — Verify everything works

1. Open your live URL
2. Enter `https://example.com` → click **Run Speed Test**
3. Check Netlify function logs: Dashboard → **Functions → log-analysis → Logs**
4. You should see: `{"event":"url_analyzed","url":"https://example.com",...}`
5. Fill in the consultation form
6. Check: `{"event":"lead_captured","name":"...","email":"...",...}`
7. If using Google Sheets: open your sheet — rows should appear within 5 seconds

---

## SEO notes

The `index.html` is pre-optimised with:

- **Title + meta description** targeting "website speed test", "page speed checker", "Core Web Vitals"
- **Canonical URL** — update to your actual domain before deploying
- **Open Graph + Twitter Card** — update `og:image` with a real screenshot
- **Schema.org JSON-LD** — `WebApplication` + `FAQPage` structured data
- **Semantic HTML** — proper H1→H2→H3 hierarchy, ARIA labels, role attributes
- **FAQ content** targeting answer-engine queries about speed, CWV, AEO

**To accelerate indexing after launch:**
1. Submit your URL in [Google Search Console](https://search.google.com/search-console)
2. Add to your XML sitemap
3. Link to the tool from your main `sonderdigital.com` website with anchor text "free website speed test"

---

## Environment variables

No environment variables are required — the Google Sheets webhook is hardwired into both functions.

If you ever need to point to a different webhook (e.g. after re-deploying the Apps Script), update the `SHEETS_WEBHOOK_URL` constant at the top of both `netlify/functions/log-analysis.js` and `netlify/functions/submit-lead.js`, then redeploy.

---

*Questions? brand@sonderdigital.com*
